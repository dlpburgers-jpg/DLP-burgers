@echo off
setlocal
set "dlp_chrome="
if exist "%ProgramFiles%\Google\Chrome\Application\chrome.exe" set "dlp_chrome=%ProgramFiles%\Google\Chrome\Application\chrome.exe"
if not defined dlp_chrome if exist "%ProgramFiles(x86)%\Google\Chrome\Application\chrome.exe" set "dlp_chrome=%ProgramFiles(x86)%\Google\Chrome\Application\chrome.exe"
if not defined dlp_chrome if exist "%LOCALAPPDATA%\Google\Chrome\Application\chrome.exe" set "dlp_chrome=%LOCALAPPDATA%\Google\Chrome\Application\chrome.exe"
if not defined dlp_chrome (
 echo No se encontro Google Chrome. Instalarlo desde https://www.google.com/chrome/
 pause
 exit /b 1
)

start "" "%dlp_chrome%" "--user-data-dir=%LOCALAPPDATA%\DLPBurgers\Mostrador" --no-first-run --no-default-browser-check --disable-background-mode "--app=https://www.dlpburgers.com/?screen=account&pc=mostrador&setup=1"
endlocal
