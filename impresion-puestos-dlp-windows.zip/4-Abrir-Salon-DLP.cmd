@echo off
setlocal
if not exist "%LOCALAPPDATA%\DLPBurgers\Salon\Default\Preferences" (
 echo Primero abre 3-Configurar-Salon-DLP.cmd, inicia sesion y prueba la impresora.
 pause
 exit /b 1
)
set "dlp_chrome="
if exist "%ProgramFiles%\Google\Chrome\Application\chrome.exe" set "dlp_chrome=%ProgramFiles%\Google\Chrome\Application\chrome.exe"
if not defined dlp_chrome if exist "%ProgramFiles(x86)%\Google\Chrome\Application\chrome.exe" set "dlp_chrome=%ProgramFiles(x86)%\Google\Chrome\Application\chrome.exe"
if not defined dlp_chrome if exist "%LOCALAPPDATA%\Google\Chrome\Application\chrome.exe" set "dlp_chrome=%LOCALAPPDATA%\Google\Chrome\Application\chrome.exe"
if not defined dlp_chrome (
 echo No se encontro Google Chrome. Instala Chrome desde google.com/chrome y volve a abrir este archivo.
 pause
 exit /b 1
)
echo DLP Salon y caja: impresion automatica en la impresora configurada como predeterminada.
start "" "%dlp_chrome%" "--user-data-dir=%LOCALAPPDATA%\DLPBurgers\Salon" --no-first-run --no-default-browser-check --disable-background-mode --kiosk-printing --app=https://www.dlpburgers.com/
endlocal
