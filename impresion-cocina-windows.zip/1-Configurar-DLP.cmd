@echo off
setlocal
set "dlp_chrome="
if exist "%ProgramFiles%\Google\Chrome\Application\chrome.exe" set "dlp_chrome=%ProgramFiles%\Google\Chrome\Application\chrome.exe"
if not defined dlp_chrome if exist "%ProgramFiles(x86)%\Google\Chrome\Application\chrome.exe" set "dlp_chrome=%ProgramFiles(x86)%\Google\Chrome\Application\chrome.exe"
if not defined dlp_chrome if exist "%LOCALAPPDATA%\Google\Chrome\Application\chrome.exe" set "dlp_chrome=%LOCALAPPDATA%\Google\Chrome\Application\chrome.exe"
if not defined dlp_chrome (
 echo No se encontro Google Chrome. Instala Chrome desde google.com/chrome y volve a abrir este archivo.
 pause
 exit /b 1
)
echo Configuracion DLP Cocina: inicia sesion y entra en Administracion - Impresora.
echo Usa Probar comanda y ticket para elegir la impresora USB y comprobar los 2 comprobantes.
start "" "%dlp_chrome%" "--user-data-dir=%LOCALAPPDATA%\DLPBurgers\Cocina" --no-first-run --no-default-browser-check --disable-background-mode --app=https://dlpburgers-jpg.github.io/DLP-burgers/
endlocal
