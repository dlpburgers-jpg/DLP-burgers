@echo off
setlocal
if not exist "%LOCALAPPDATA%\DLPBurgers\Cocina\Default\Preferences" (
 echo Primero abre 1-Configurar-DLP.cmd, inicia sesion y prueba la impresora.
 pause
 exit /b 1
)
set "dlp_chrome="
if exist "%ProgramFiles%\Google\Chrome\Application\chrome.exe" set "dlp_chrome=%ProgramFiles%\Google\Chrome\Application\chrome.exe"
if not defined dlp_chrome if exist "%ProgramFiles(x86)%\Google\Chrome\Application\chrome.exe" set "dlp_chrome=%ProgramFiles(x86)%\Google\Chrome\Application\chrome.exe"
if not defined dlp_chrome if exist "%LOCALAPPDATA%\Google\Chrome\Application\chrome.exe" set "dlp_chrome=%LOCALAPPDATA%\Google\Chrome\Application\chrome.exe"
if not defined dlp_chrome (
 echo No se encontro Google Chrome. Instala Chrome desde google.com/chrome y volve a abrir este archivo.
 pause
 exit /b 1
)
echo DLP Cocina: impresion automatica. Usa la impresora de cocina configurada como predeterminada.
start "" "%dlp_chrome%" "--user-data-dir=%LOCALAPPDATA%\DLPBurgers\Cocina" --no-first-run --no-default-browser-check --disable-background-mode --kiosk-printing --app=https://dlpburgers-jpg.github.io/DLP-burgers/
endlocal
